fetchData();

async function fetchData(){
    let webAPI = 'https://api.restful-api.dev/objects';
    const response = await fetch(webAPI);
    const data = await response.json();
    let tblPhoes = document.querySelector('#tblPhones tbody');

    for (let x = 0; x < data.length; x++){
        let current = data[x];
        let tr = document.createElement('tr');
        tr.innerHTML += `<td> ${current.id}</td><td>${current.name}</td><td>${current.data && current.data.color ? current.data.color : 'No Color' }</td>`;

        tblPhones.append(tr);
    }

}