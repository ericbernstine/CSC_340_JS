populate();
let selectedYear = document.querySelector('#years')
var value = selectedYear.value;

document.querySelector('#submit').addEventListener('click', () => {
    remove();
    value = selectedYear.value;  
    populate(value);
})

function remove(){
    let tbody = document.querySelector('.tblReturn tbody');
    tbody.innerHTML = ''
}

function populate(checkInt){    
    let tbody = document.querySelector('.tblReturn tbody');
    let year;
    if (!checkInt){
        year = 30;
    } else {
        year = checkInt
    }
    let random = (Math.random() * (0.15 - 0.10) + 0.10)
    amtDOW=amtSP=amtNSDQ=amtRandom = 50000;
    let usd = new Intl.NumberFormat('en-US', {style: 'currency', currency: 'USD'});


    for (let cy = 1; cy <= year; cy++){
        tbody.innerHTML += `<tr><td>${cy}</td>
            <td>${usd.format(amtSP)}</td>
            <td>${usd.format(amtNSDQ)}</td>
            <td>${usd.format(amtDOW)}</td>
            <td>${usd.format(amtRandom)}</td>
            </tr>`;
        amtSP *= (1 + .10)
        amtNSDQ *= (1 + .2218)
        amtDOW *= (1 + .1072)
        amtRandom *= (1 + random)
    }

}