
let imgGhost = document.querySelector('#imgGhost');
let scoob = document.querySelector('#scoob')
let points = 0;
let snd = new Audio('../sounds/ghost.mp3');
let score = document.querySelector('#score');
let rounds = 0;
let roundsListener = document.querySelector('#rounds')


document.querySelector('button').addEventListener('click', (btn) => {
    btn.target.style.display = 'none';
    setInterval(flash(imgGhost), 1500);
    setInterval(flash(scoob), 3000)
})

imgGhost.addEventListener('click', () => {
    points++;
    score.innerText = points;
    imgGhost.style.display='none';
    snd.pause();
    snd.currentTime = 0;
})

scoob.addEventListener('click', () => {
    points += 2;
    score.innerText = points;
    scoob.style.display = 'none';
})

function flash(prop){
    if (prop.style.display == 'none'){
        snd.play();
        prop.style.display = 'inline-block';
        prop.style.top = Math.random() * 100 + '%';
        prop.style.left = Math.random() * 100 + '%';
    } else {
        prop.style.display='none';
    }
    rounds++;
    if (rounds > 10){
        let check = confirm(`GAME OVER, FINAL SCORE: ${points}`)
    if (check || check == false)
        location.reload();
    }
    roundsListener.innerText = `Rounds: ${rounds}`;
}
