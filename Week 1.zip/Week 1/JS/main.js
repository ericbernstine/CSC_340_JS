let audio = new Audio('sounds/song.mp3');
let blnPlay = false;
let timer; 

document.querySelector('#song').addEventListener('click', () => {
    play();
})

function play(){
    if (!blnPlay){
        audio.play();
        timer = setInterval(changeBackground, 2000) // run changeBackground every 2 seconds.
    } else {
        audio.pause();
        clearInterval(timer);
    }
    // toggle blnPlay value, essentially reverse the current value.
    blnPlay=!blnPlay;

}

function changeBackground(){
    let bk = document.body;
    let img = document.querySelector('#song');

    if (bk.style.background=="#000"){
        bk.style.background="white";
        img.style.borderColor='#000';
    } else {
        bk.style.background="#000";
        img.style.borderColor='white';
    }
}


// create button that chages the audio to create a different song. 