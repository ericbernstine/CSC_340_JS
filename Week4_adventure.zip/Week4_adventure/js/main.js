let curScene = 0;
let curPoints = 0;
const pScene = document.querySelector('#pScene');
const qScene = document.querySelector('#qScene');
const imgScene = document.querySelector('#imgScene');
const sndWrong = new Audio('sounds/wrong.wav');
const btnGo = document.querySelector('#btnGo');
const textInput = document.querySelector('#txtCom');
const points = document.querySelector('#points');


function begin(){
    loadScene();
}

btnGo.addEventListener('click', () =>{
    let c = map[curScene];
    console.log(c.ans);
    let userAnswer = textInput.value
    if (userAnswer.toLowerCase() == c.ans){
        alert('Correct!');
        curPoints++;
        points.innerText  = `points: ${curPoints}`
    } else {
        alert('Incorrect, try again');
    }
    textInput.value = "";
})

function moveTo(d){
    let c = map[curScene];
    if (c[d] > -1){
        curScene = c[d];
        loadScene();
    } else;{
        sndWrong.play();
    }
}

function loadScene(){
    let c = map[curScene];
    pScene.textContent = '';
    qScene.textContent = '';
    typeText(c.Scene);
    typeQues(c.ques);
    imgScene.src = `images/${c.Img}`;
    if (c.Snd.length>1){
        let snd = new Audio(`sounds/${c.Snd}`)
    }
}

async function typeText(value){
    let i = 0; 
    let txt = value.split('');
    let btns = document.querySelectorAll('.directions button');
    btns.forEach((elem) => {
        elem.disabled=true;
    });
    while(i < txt.length){
        pScene.textContent += txt[i];
        i++;
        await sleep(40);
    }
    btns.forEach((elem) => {
        elem.disabled = false;
    })
}

async function typeQues(value){
    let i = 0; 
    let txt = value.split('');
    while(i < txt.length){
        qScene.textContent += txt[i];
        i++;
        await sleep(100);
    }
}

function sleep(ms){
    return new Promise(resolve => setTimeout(resolve, ms));
}

begin();


// 1. add another scene. 

// 2. add in questions and answer for the textbox, if correct add point. add questions ONLY to first and third scene. 

// 