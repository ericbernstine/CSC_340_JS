 let map=[
    {
        Scene:"You are standing before the great echo forest.  A small path is in front of you.",
        Pos:0,
        N:1,
        S:-1,
        W:-1,
        E:-1,
        Img:"s0.jpeg",
        Snd:"", 
        ques: "Like Louis Armstrong said. I see..?",
        ans: 'trees of green' 
    },  {
        Scene:"You walk into the forest and are confronted with a small stream.",
        Pos:1,
        N:-1,
        S:0,
        W:2,
        E:3,
        Img:"s1.jpeg",
        Snd:"", 
        ques: "It's not just a bolder its a ...",
        ans: 'rock'
    },{
        Scene:"Strolling along side the stream.  You notice a bird chirping.",
        Pos:2,
        N:-1,
        S:-1,
        W:-1,
        E:3,
        Img:"s2.jpeg",
        Snd:"birdie.mp3", 
        ques: "It's not just a bolder its a ...",
        ans: 'rock'
    },{
        Scene:"Not too far past the stream resides a rocky terrain.",
        Pos:3,
        N:-1,
        S:-1,
        W:1,
        E:-1,
        Img:"s3.png",
        Snd:"", 
        ques: "It's not just a bolder its a ...",
        ans: 'rock'
    }
]